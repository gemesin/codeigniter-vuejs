<?php
$route['admin/login'] = 'client/auth/admin_login';


