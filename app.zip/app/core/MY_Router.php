<?php

/*
 * Custom router function v 0.1
 *
 * Add functionality : read into more than one sub-folder
 *
 */

Class MY_Router extends CI_Router
{

   
}
