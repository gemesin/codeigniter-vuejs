<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Public_Controller extends Base_Controller
{

    public function __construct()
    {
        parent::__construct();
    }
}
