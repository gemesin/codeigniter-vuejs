const firebaseConfig = {
  apiKey: 'AIzaSyCK63u3XBPxUI8bpHB0NgkRnKMhDz2OD8E',
  authDomain: 'store-esoda.firebaseapp.com',
  projectId: 'store-esoda',
  storageBucket: 'store-esoda.appspot.com',
  messagingSenderId: '541008352495',
  appId: '1:541008352495:web:68335615ab5537edec371a',
  measurementId: 'G-Q9NVX6YH6R',
}

firebase.initializeApp(firebaseConfig);
